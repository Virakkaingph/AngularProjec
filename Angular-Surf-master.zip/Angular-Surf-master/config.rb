encoding = "utf-8"
http_path = "/"

css_dir = "front/assets/css"
sass_dir = "front/assets/scss"

images_path = "front/assets/img/"
fonts_path = "front/assets/font/"
sprite_load_path = "front/assets/img/"

generated_images_dir = "front/assets/img/sprites"

relative_assets = false