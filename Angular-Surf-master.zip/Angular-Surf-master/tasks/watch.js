'use strict';

var gulp = require('gulp');

gulp.task('watch', [ 'css:watch', 'js:watch' ]);